
# Ta Formation Pro – Site Prêt à Lancer

Ce projet contient :
- Un backend Node.js connecté à MongoDB
- Un frontend prêt à déployer sur Vercel
- Intégration Stripe prévue
- Un compte administrateur initialisé

## Accès
- Email admin : taformation.pro@gmail.com
- Mot de passe : Sharone95200

## Déploiement rapide

### Backend (Render)
1. Crée un compte sur https://render.com
2. Crée un nouveau Web Service
3. Branche ce code (backend)
4. Ajoute les variables suivantes :
   - MONGO_URI
   - JWT_SECRET
   - STRIPE_SECRET_KEY

### Frontend (Vercel)
1. Crée un compte sur https://vercel.com
2. Uploade le dossier /frontend
3. Modifie les appels d'API si nécessaire

Besoin d'aide ? Reviens vers moi ici ou par e-mail.
